import android.util.Log;

public class ExternalCode {
    public ExternalCode() {
        Log.d("htbridge", "I am instancied");
    }

    public String run() {
        return "I am working";
    }
}